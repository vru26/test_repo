package com.loan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.loan.dao.ICustomerDao;
import com.loan.model.Customer;
@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	private ICustomerDao customerDao;


	@Override

	public void addCustomer(Customer cust) {
		// TODO Auto-generated method stub
		System.out.println("inside");
		customerDao.addCustomer(cust);
		
	}

	@Override

	public void updateCustomer(Customer cust) {
		// TODO Auto-generated method stub
		customerDao.updateCustomer(cust);
		
	}

}

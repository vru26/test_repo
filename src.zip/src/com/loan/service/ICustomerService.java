package com.loan.service;

import com.loan.model.Customer;

public interface ICustomerService {
	public void addCustomer(Customer cust);
	public void updateCustomer(Customer cust);

}

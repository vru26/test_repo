package com.loan.dao;

import com.loan.model.Customer;

public interface ICustomerDao {

		public void addCustomer(Customer cust);//insert
		public void updateCustomer(Customer cust);//update/modify
	

}

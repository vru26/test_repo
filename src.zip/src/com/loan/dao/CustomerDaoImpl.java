package com.loan.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.loan.model.Customer;

@Repository
public class CustomerDaoImpl implements ICustomerDao{
	static Transaction tcx ;
	private SessionFactory sessionFactory;
		
	@Autowired // if annotated as repository then dont need to put entries in .xml
	public void setSessionFactory(SessionFactory sf) {
	    this.sessionFactory = sf;
	}


	@Override
	public void addCustomer(Customer cust) {
		
		try {
			System.out.println("inside add");
	    Session session = this.sessionFactory.openSession();
        tcx = session.beginTransaction();
        session.save(cust);
        tcx.commit();
        session.close();
		}
		catch(Throwable t) {
			t.printStackTrace();
		}
	}
	

	@Override
	public void updateCustomer(Customer cust) {
	    Session session = this.sessionFactory.openSession();
        tcx = session.beginTransaction();
        session.update(cust);
        tcx.commit();
        session.close();
		
	}
	

}

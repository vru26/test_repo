package com.loan.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
//import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.loan.exception.CustomException;
import com.loan.model.Customer;
import com.loan.service.ICustomerService;
@Controller
public class CustomerController {

	@Autowired	
	private ICustomerService CustomerService;


	@Qualifier(value = "CustomerService")
	public void setCustomerService(ICustomerService ps) {
		this.CustomerService = ps;
	}

//	@ExceptionHandler(CustomException.class)
//	public ModelAndView handleCustomerNotFoundException(CustomException ex) {
//		Map<String, CustomException> model = new HashMap<String, CustomException>();
//		model.put("exception", ex);
//		return new ModelAndView("error", model);

//	}

//	@ExceptionHandler(Exception.class)
//	public ModelAndView handleException(Exception ex) {
//		Map<String, Exception> model = new HashMap<String, Exception>();
//		model.put("exception", ex);
//		return new ModelAndView("error", model);
//
//	}

	// For add and update Customer both
	/*
	 * @RequestMapping(value = "/Customer/add", method = RequestMethod.POST)
	 * 
	 * @ExceptionHandler({ CustomException.class }) public String addCustomer(
	 * 
	 * @ModelAttribute("Customer")
	 * 
	 * @Validated Customer cust, BindingResult result, Model model) { if
	 * (!result.hasErrors()) { if (cust.getId() == null) { // new Customer, add it
	 * this.CustomerService.addCustomer(cust); } else { // existing Customer, call
	 * update this.CustomerService.updateCustomer(cust); } return
	 * "redirect:/Customer"; } //model.addAttribute("listCustomers",
	 * this.CustomerService.listCustomers()); return "Customer";
	 * 
	 * }
	 */
	@RequestMapping(value="customer",method=RequestMethod.POST)
	
	public String submit(@Valid @ModelAttribute("cust") 
	Customer cust ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		try {
		String view="";
		System.out.println("hi");
	if(bindingResult.hasErrors())
	{
		view="successPage";
		return view;
	}
	else
	{
		System.out.println(cust.getFirstName());
		CustomerService.addCustomer(cust);
		
		view="successPage";
		return view;
		
	}
	}
	catch(Throwable t) {
		t.printStackTrace();
	}
		return "successPage";
	}

	@RequestMapping("HomePage")
	public String showLoginView(Model modal)
	{
		modal.addAttribute("cust", new Customer());
		String view="form";
		return view;
	}
	
}
